$(document).ready(function() {
	$('main').fullpage({
		sectionSelector: 'section',
		scrollingSpeed: 1000,
    touchSensitivity: 15
	});
});
